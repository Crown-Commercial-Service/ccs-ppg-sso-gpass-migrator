# Dummy Lambda function to zip and use during TF verification
def lambda_handler(event, context):
    pass
